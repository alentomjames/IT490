<?php
    require_once 'rabbitmq_connection.php';

    recieveLogs();
?>